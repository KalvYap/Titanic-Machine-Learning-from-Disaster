%read the train table
traintable = readtable('train.csv');
datatable = (table2cell(traintable));
survived = cell2mat(datatable(:,2));
pclass = cell2mat(datatable(:,3));
sex = datatable(:,5);
age = cell2mat(datatable(:,6));

%filling empty ages with average age
mean_age = mean(age,'omitnan');
age(isnan(age))= mean_age;

agediff = discretize(age, [0 15 25 60 100],'categorical',{'Under 15', '15-25', '25-60', 'Above 60'});
agediff = grp2idx(agediff);
sex = grp2idx(sex);
arrangedtable = table(pclass, sex, agediff, survived);

%decision tree
dectree = fitctree(arrangedtable(:,1:3),arrangedtable(:,4));

[~,~,~,BestLevel] = cvloss(dectree,'subtrees','all','treesize','min');
pruningtree = prune(dectree,'Level',BestLevel);
view(pruningtree,'mode','graph')

label = predict(pruningtree,arrangedtable(:,1:end-1));
conmattree = confusionmat(survived,label);
acctree = trace(conmattree)/sum(conmattree, 'all');

%read the test table
traintable = readtable('test.csv');
datatable = (table2cell(traintable));

pclass = cell2mat(datatable(:,2));
sex = datatable(:,4);
age = cell2mat(datatable(:,5));
PassengerID = cell2mat(datatable(:,1)); 

%filling empty ages with average age
mean_age = mean(age,'omitnan');
age(isnan(age))= mean_age;

agediff = discretize(age, [0 15 25 60 100],'categorical',{'Under 15', '15-25', '25-60', 'Above 60'});
agediff = grp2idx(agediff);
sex = grp2idx(sex);
testtable = table(pclass, sex, agediff);

%decision tree
ytree = predict(pruningtree,testtable(:,1:end)); 
Survived = ytree;

out = table(PassengerID, Survived);
writetable(out,'predictions.csv');
