traintable1 = readtable('train.csv');

traintable1.Name=[];
traintable1.Ticket=[];
traintable1.Cabin=[];

agenan=median(traintable1.Age,'omitnan');
traintable1.Age=fillmissing(traintable1.Age,"constant",agenan);

t = traintable1.Embarked;
conv = cell2mat(t);
modever = mode(conv);

traintable1.Embarked = fillmissing(traintable1.Embarked,'constant',modever);
traintable1.Embarked = categorical(traintable1.Embarked);
traintable1.Embarked = renamecats(traintable1.Embarked,{'S','C','Q'},{'1','2','3'});
traintable1.Embarked = str2double(string(traintable1.Embarked));

traintable1.Sex = categorical(traintable1.Sex);
traintable1.Sex = renamecats(traintable1.Sex,{'male','female'},{'1','2'});
traintable1.Sex = str2double(string(traintable1.Sex));

sum(ismissing(traintable1))

traintable2 = readtable('test.csv');
passid = traintable2.PassengerId;

traintable2.Name=[];
traintable2.Ticket=[];
traintable2.Cabin=[];

agenan=median(traintable2.Age,'omitnan');
traintable2.Age=fillmissing(traintable2.Age,"constant",agenan);

a = traintable2.Embarked;
conv1 = cell2mat(a);
modever1 = mode(conv1);

traintable2.Embarked = fillmissing(traintable2.Embarked,'constant',modever1);
farenan=median(traintable2.Fare,'omitnan');
traintable2.Fare=fillmissing(traintable2.Fare,"constant",farenan);

traintable2.Sex = categorical(traintable2.Sex);
traintable2.Sex = renamecats(traintable2.Sex,{'male','female'},{'1','2'});
traintable2.Sex = str2double(string(traintable2.Sex));

traintable2.Embarked = categorical(traintable2.Embarked);
traintable2.Embarked = renamecats(traintable2.Embarked,{'S','C','Q'},{'1','2','3'});
traintable2.Embarked = str2double(string(traintable2.Embarked));

sum(ismissing(traintable2))

traintable1_train = traintable1(:,[1 3:8]);
traintable2_train =traintable1(:,2);

model = fitcknn(traintable1_train,traintable2_train,'OptimizeHyperparameters','auto');

prediction=predict(model,traintable2);

output=[passid prediction];

store=array2table(output,'VariableNames',{'PassengerId','Survived'});

writetable(store,'predictions.csv','Delimiter',',');

