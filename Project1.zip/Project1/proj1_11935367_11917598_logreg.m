%read the train table
traintable = readtable('train.csv');
datatable = (table2cell(traintable));
survived = cell2mat(datatable(:,2));
pclass = cell2mat(datatable(:,3));
sex = datatable(:,5);
age = cell2mat(datatable(:,6));

%filling empty ages with average age
mean_age = mean(age,'omitnan');
age(isnan(age))= mean_age;

agediff = discretize(age, [0 15 25 60 100],'categorical',{'Under 15', '15-25', '25-60', 'Above 60'});
agediff = grp2idx(agediff);
sex = grp2idx(sex);
arrangedtable = table(pclass, sex, agediff, survived);

%logistic regression
model = fitglm(arrangedtable, 'Distribution','binomial');
ypred = predict(model,arrangedtable(:,1:end-1));
ypred = round(ypred);
confusionchart(ypred,survived);

%read the test table
testtable = readtable('test.csv');
datatesttable = (table2cell(testtable));

pclass = cell2mat(datatesttable(:,2));
sex = datatesttable(:,4);
agetest = cell2mat(datatesttable(:,5));
PassengerID = cell2mat(datatesttable(:,1)); 

%filling empty ages with average age
mean_age_test = mean(agetest,'omitnan');
agetest(isnan(agetest))= mean_age_test;

agediff = discretize(agetest, [0 15 25 60 100],'categorical',{'Under 15', '15-25', '25-60', 'Above 60'});
agediff = grp2idx(agediff);
sex = grp2idx(sex);
testtable = table(pclass, sex, agediff);

%logistic regression
ypred2 = predict(model,testtable(:,1:end));
Survived = round(ypred2);


out = table(PassengerID, Survived);
writetable(out,'predictions.csv');
